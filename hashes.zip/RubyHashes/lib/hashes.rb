# RubyHashes
# Part I
def array_2_hash (emails, contacts) #array, hash
    if (emails.empty?)
        return contacts
    else 
        i = 0
        contacts.each_key do |key|
        contacts[key] = emails[i]
        i += 1
        end
    end
	return contacts
end

# Part II
#given [["bobsmith@example.com", "555-555-5555"],["sallyfield@example.com","111-111-1111"]], {'Bob Smith':{}, 'Sally Field':{}})
#return ({:"Bob Smith"=>{:email=>"bobsmith@example.com", :phone=>"555-555-5555"}, :"Sally Field"=>{:email=>"sallyfield@example.com", :phone=>"111-111-1111"}}
def array2d_2_hash (contact_info, contacts) 
        i = 0
        contacts.each_key do |key|
            if (contact_info[i].length == 2)
                contacts[key] = { email: contact_info[i][0], phone: contact_info[i][1] }
                i += 1
            end
        end
    return contacts
end

# Part III
#({:"Bob Smith"=>{:email=>"bobsmith@example.com", :phone=>"555-555-5555"}, :"Sally Field"=>{:email=>"sallyfield@example.com", :phone=>"111-111-1111"}})) 
#([["bobsmith@example.com","sallyfield@example.com"],["555-555-5555","111-111-1111"],["Bob Smith","Sally Field"]])
def hash_2_array (contacts)
    names = []
    emails = []
    phones = []
    contact_keys = contacts.keys
    contact_keys.each_with_index do |key, i|
        names.push(key.to_s)
        emails.push(contacts.dig(key, :email).to_s)
        phones.push(contacts.dig(key, :phone).to_s)
    end
return [emails, phones, names]
end
