module FunWithStrings
  def palindrome?
    str = self.downcase.scan(/\w/)
    return  str == str.reverse
  end
  
  def count_words
    word_count = Hash.new(0)
    words = self.split(/[^a-zA-Z]/)
    words.each { |word| word_count[word.downcase] += 1 }
    word_count.delete_if { |key, value| key == "" }
    return word_count

  end
  
  def anagram_groups
    groups = self.split.group_by{|w| w.chars.sort}.values
    return groups
  end
end

# make all the above functions available as instance methods on Strings:

class String
  include FunWithStrings
end
