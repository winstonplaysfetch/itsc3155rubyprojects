# Strings and Regular Expressions

# Part I
def hello(name)
  return "Hello, " + name
end

# Part II
def starts_with_consonant? (s)
  return (/\A[a-z]/ =~ s.downcase && (/\A[aeiou]/ =~ s.downcase) == nil )
end

# Part III
def binary_multiple_of_4? (s)
  return /^[10]*0$/.match(s)
end
